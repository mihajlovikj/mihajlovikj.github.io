//
//  Stack.hpp
//  Lec_02_07_20
//
//  Created by Vidoje Mihajlovikj on 2/7/20.
//  Copyright © 2020 Vidoje Mihajlovikj. All rights reserved.
//

#ifndef Stack_h
#define Stack_h

class Stack : public IContainer{
private:
public:
    Stack(){};
    void push_back(const int & element){
        std::cout << "Hello from Stack push_back" << std::endl;
    }
    ~Stack(){};
};

#endif /* Stack_h */
