//
//  Vector.cpp
//  Lec_02_07_20
//
//  Created by Vidoje Mihajlovikj on 2/7/20.
//  Copyright © 2020 Vidoje Mihajlovikj. All rights reserved.
//

#include <stdio.h>
