//#include <iostream>
//#include <stdio.h>
//#include "IContainer.hpp"
//#include "Vector.hpp"
//#include "Stack.hpp"
//
//void testPushBack(IContainer * container){
//    container->push_back(10);
//}
//
//int main(){
//    IContainer * vector = new Vector(10);
//    IContainer * stack = new Stack();
//    testPushBack(vector);
//    testPushBack(stack);
//
//    //IContainer container;
//}


//
//  main.cpp
//  Lec_02_07_20
//
//  Created by Vidoje Mihajlovikj on 2/7/20.
//  Copyright © 2020 Vidoje Mihajlovikj. All rights reserved.
//

#include <iostream>
#include <stdio.h>

class A
{
public:
    A() {
        std::cout << "A()" << std::endl;
        init();
    }

    virtual void init() {
        printf("A::virtual_function called\n");
    }

    virtual ~A() {
    }
};

class B : public A
{
public:
    B(){
        std::cout << "B()" << std::endl;
    }
    // override virtual function in A
    void init()
    {
        printf("B::virtual_function called\n");
    }
};

class C : public A
{
public:
    C(){
        std::cout << "B()" << std::endl;
    }
    // override virtual function in A
    void init()
    {
        printf("B::virtual_function called\n");
    }
};

class D : public A
{
public:
    D(){
        std::cout << "B()" << std::endl;
    }
    // override virtual function in A
    void init()
    {
        printf("B::virtual_function called\n");
    }
};

int main(int argc, char **argv)
{
    // Call to virtual_function during construction doesn't
    // behave like normal virtual function call.
    // Print statement shows it invokes A::virtual_function,
    // even though we are constructing an instance of B, not A.
    B myObject;

    // This call behaves like a normal virtual function call.
    // Print statement shows it invokes B::virtual_function.
    //myObject.virtual_function();

    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
