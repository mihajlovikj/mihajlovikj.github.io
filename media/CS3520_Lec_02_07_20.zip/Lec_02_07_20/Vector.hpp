//
//  Vector.hpp
//  Lec_02_07_20
//
//  Created by Vidoje Mihajlovikj on 2/7/20.
//  Copyright © 2020 Vidoje Mihajlovikj. All rights reserved.
//

#ifndef Vector_h
#define Vector_h


class Vector : public IContainer{
private:
    int * data;
    int size;
    int capacity;
public:
    Vector(int capacity){
        if ( this->capacity <= 0 ){
            throw "Invalid capacity";
        }
        
        this->data = new int[capacity];
        this->size = 0;
    }
    void push_back(const int & element){
        std::cout << "Pushing back from Vector" << std::endl;
    }
    
    ~Vector(){}
};

#endif /* Vector_h */
