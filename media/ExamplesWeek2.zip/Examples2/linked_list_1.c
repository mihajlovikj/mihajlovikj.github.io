// Include libraries
#include <stdio.h> // Bring in standard functions like printf
#include <stdlib.h> // Bring in malloc and free

// Our custom data structure
// We can use it as 'struct node' or 'node_t'
typedef struct node{
    struct node* next;	// points to the next thing.
    int wins;			// Essentially chaining nodes together.
    int years;
}node_t;


// A function which allocates a linked list with three items.
// It returns the 'head' of the list so we can access it later.
node_t* create_list(){
	// Create our nodes.
	// Note: malloc within malloc we are requesting some memory
	// 		 for the size of a node_t.
	//		 Say if node_t is '12 bytes', then malloc gives us 12 bytes each.
    node_t* year2018 = malloc(sizeof(node_t));
    node_t* year2017 = malloc(sizeof(node_t));
    node_t* year2016 = malloc(sizeof(node_t));
	// Set our fields in each of our nodes
    year2018->years = 2018; 
    year2017->years = 2017; 
    year2016->years = 2016; 
    
    year2018->wins = 108; 
    year2017->wins = 93; 
    year2016->wins = 92; 
	// Link them together.
	// Notes that year2016 is the 'tail' node.
    year2018->next = year2017;
    year2017->next = year2016;
    year2016 = NULL;

	// Once again, return our 'head' node.
	// Otherwise we have no way of retrieving this list after
	// we leave this function.
    return year2018;
}


int main(){
	// Create a node_t of our list.
    node_t* redsox;
	// Assign our list to a newly created list.
    redsox = create_list();
	
	
	// Now we want to do something interesting, like iterate
	// through the list.
	// We create a 'temporary' node to do this.
	// Note,  you can have as many 'temporaries' as you want.
	// And because we have already allocated memory for 'redsox' (which was returned from create_list)
	// we can simply point to it, and know something is there.
    node_t* iterator = redsox;

	// We iterate until we reach the end of the list.
    while(iterator!=NULL){
		// print out each of the fields.
        printf("wins in %d are %d\n", iterator->years,iterator->wins);
		// This is the iterator 'pattern' in that we move forward by 
		// making the new place the iterator points to, equal to the next node in the linked list.
        iterator=iterator->next;        
    }

	
	// To be continued...by you!
    // Hmmm.. how do we 'free' our linked list now?
    // exercise for the reader!

    return 0;
}
