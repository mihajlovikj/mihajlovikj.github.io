// compile: clang 1_sizeof.c -o sizeof
// run ./sizeof
#include <stdio.h>

int main(){

    // data type sizes
    // Use the 'sizeof' function
    // %lu is a format specifier for 'long unsigned int'
    printf("char: %lu\n", sizeof(char));
    printf("int: %lu\n", sizeof(int));
    printf("int: %lu\n", sizeof(long unsigned int));

    return 0;
}
