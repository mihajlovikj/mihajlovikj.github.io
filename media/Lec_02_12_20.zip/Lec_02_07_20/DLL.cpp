//
//  Stack.cpp
//  Lec_02_07_20
//
//  Created by Vidoje Mihajlovikj on 2/11/20.
//  Copyright © 2020 Vidoje Mihajlovikj. All rights reserved.
//

#include <stdio.h>
#include "DLL.hpp"

Node::Node(int data) {
    this->data = data;
    this->previous = nullptr;
    this->next = nullptr;
}

void Node::set_previous(Node *previous) {
    this->previous = previous;
}

void Node::set_next(Node *next) {
    this->next = next;
}

Node *Node::get_previous() const {
    return this->previous;
}

Node *Node::get_next() const {
    return this->next;
}

int Node::get_data() const {
    return this->data;
}

int & Node::get_data() {
    return this->data;
}

// Constructor.
DLL::DLL() {
    this->count = 0;
    this->head = nullptr;
    this->tail = nullptr;
}

// Destructor.
DLL::~DLL() {
    Node *iterator = this->head;
    
    while (iterator != nullptr) {
        Node *temp = iterator;
        iterator = iterator->get_next();
        delete temp;
    }
}

// Pushes a new item to the end of the DLL (after the last node in the list).
void DLL::push_back(const int & item) {
    Node *new_node = new Node(item);
    
    if (this->tail == nullptr) {
        this->head = new_node;
        this->tail = new_node;
    } else {
        this->tail->set_next(new_node);
        new_node->set_previous(this->tail);
        this->tail = new_node;
    }
    
    this->count++;
}

// Returns the last item in the DLL, and also removes it from the list.
void DLL::pop_back() {
    if (this->count <= 0) {
        throw std::out_of_range("Empty vector.");
    }
    
    int value = this->tail->get_data();
    Node *node_popped = this->tail;
    
    if (this->count == 1) {
        this->head = nullptr;
        this->tail = nullptr;
    } else {
        this->tail = this->tail->get_previous();
        this->tail->set_next(nullptr);
    }
    
    this->count--;
    
    delete node_popped;
    
    //return value;
}

// Inserts a new node before the node at the specified position.
void DLL::insert(int pos, int item) {
    if ((pos < 0) || (pos > this->count)) {
        throw std::out_of_range("Invalid pos or empty vector.");
    }
    
    if (pos == 0) {
        this->push_front(item);
        return;
    }
    
    if (pos == this->count) {
        this->push_back(item);
        return;
    }
    
    Node *new_node = new Node(item);
    Node *iterator = this->head;
    
    for (int i = 0; i < pos; i++) {
        iterator = iterator->get_next();
    }
    
    new_node->set_next(iterator);
    new_node->set_previous(iterator->get_previous());
    iterator->get_previous()->set_next(new_node);
    iterator->set_previous(new_node);
    
    this->count++;
}

//// Returns the item at position pos starting at 0 (0 being the first item).
//int DLL::get(int pos) const {
//    if ((pos < 0) || (pos >= this->count)) {
//        throw std::out_of_range("Invalid pos or empty vector.");
//    }
//    
//    Node *iterator = this->head;
//    
//    for (int i = 0; i < pos; i++) {
//        iterator = iterator->get_next();
//    }
//    
//    return iterator->get_data();
//}

// Returns the item at position pos starting at 0 (0 being the first item).
int & DLL::get(int pos){
    if ((pos < 0) || (pos >= this->count)) {
        throw std::out_of_range("Invalid pos or empty vector.");
    }
    
    Node *iterator = this->head;
    
    for (int i = 0; i < pos; i++) {
        iterator = iterator->get_next();
    }
    
    return iterator->get_data();
}

// Queries the current size of a DLL.
int DLL::size() const {
    return this->count;
}

// Pushes a new item to the front of the DLL (before the first node in the list).
void DLL::push_front(int item) {
    Node *new_node = new Node(item);
    
    if (this->head == nullptr) {
        this->head = new_node;
        this->tail = new_node;
    } else {
        this->head->set_previous(new_node);
        new_node->set_next(this->head);
        this->head = new_node;
    }
    
    this->count++;
}
int & DLL::operator[](int index){
    return this->get(index);
}
