#include <iostream>
#include <stdio.h>
#include "IContainer.hpp"
#include "Vector.hpp"
#include "DLL.hpp"

void swap(int & a, int & b){
    int temp = a;
    a = b;
    b = temp;
}

// A function to implement bubble sort
void sort(IAccessor & container, int size)
{
    int i, j;
    int n = size;

    for (i = 0; i < n-1; i++)
        // Last i elements are already in place
        for (j = 0; j < n-i-1; j++)
            if (container.get(j) > container.get(j+1))
                swap(container.get(j), container.get(j+1) );
}

void printContainer(IContainer container){
    container->push_back(10);
    for ( int i = 0; i < container->size(); i++){
        std::cout << container->get(i) << ", ";
    }
    std::cout << std::endl;
}

void initContainer(IContainer * container){
    container->push_back(40);
    container->push_back(20);
    container->push_back(50);
    container->push_back(10);
}

void modifyContainer(IContainer * container){
    container->pop_back();
    container->pop_back();
}

void modifyContainer2(int & value){
    value = 400;
}

class VectorWithIterators{
private:
    int * data;
    int size;
    int capacity;
public:
    typedef int * iterator;
    
    VectorWithIterators(){
        this->capacity = 10;
        this->size = 0;
        data = new int[capacity];
    }
    
    void push_back(int value){
        data[this->size] = value;
        this->size++;
    }
    
    int * begin(){
        return data;
    }
    int * end(){
        return (data+size);
    }
};

#include <vector>
void print(std::vector<int>::reverse_iterator start, std::vector<int>::reverse_iterator end){
    while ( start != end){
        std::cout << *start << ", ";
        
        start++;
    }
    std::cout << std::endl;
}
//
//void printReverse(std::vector<int>start, std::vector<int>::iterator end){
//    end--;
//
//    while ( end != (start - 1) ){
//        std::cout << *end << ", ";
//
//        end--;
//    }
//    std::cout << std::endl;
//}

int main(){
    std::vector<int> v1;
    v1.push_back(10);
    v1.push_back(20);
    v1.push_back(30);
    v1.push_back(40);
    
    
    print(v1.rbegin(), v1.rend());
    
   // printReverse(v1.begin(), v1.end() );
    
//    for ( std::vector<int>::const_iterator itr = v1.cbegin(); itr != v1.cend(); itr++){
//       // *itr = *itr * 10;
//    }
//
//    for ( std::vector<int>::const_iterator itr = v1.cbegin(); itr != v1.cend(); itr++){
//        std::cout << *itr << ", ";
//    }
//    std::cout << std::endl;
    
//    for (int i = 0; i < v1.size(); i++){
//        std::cout << v1[i] << ", ";
//    }
//    VectorWithIterators v2;
//    v2.push_back(10);
//    v2.push_back(20);
//    v2.push_back(30);
//
//    for ( std::vector<int>::iterator itr = v1.begin(); itr != v1.end(); itr++){
//        std::cout << *itr << ", ";
//    }
//
//    for ( VectorWithIterators::iterator itr = v2.begin() + 10; itr != v2.end(); itr++){
//        std::cout << *itr << ", ";
//    }
//
//    std::cout << std::endl;
//    int myArray[3] = {1,2,3};
//
//    myArray[1] = 4;
//    *(myArray + 1) = 10;
//
//    for ( int * itr = myArray; itr != (myArray + 3); itr++){
//        std::cout << *itr << ", ";
//    }
//
//    std::cout << std::endl;
//
//    std::cout << std::endl;
//
    
//    IContainer * vector = new Vector(10);
//    IContainer * dll = new DLL();
//    initContainer(vector);
//    initContainer(dll);
//
//    vector->get(2) = 100;
//    modifyContainer2(vector->get(2));
//
//    printContainer(vector);
    //printContainer(dll);
    
    //sort(static_cast<IAccessor *>(vector), vector->size() );
    //sort(*vector, vector->size() );
    //sort(dll, dll->size() );
    
    //printContainer(vector);
    //sort(vector);
    
//    modifyContainer(vector);
//    modifyContainer(dll);
    
//    printContainer(vector);
//    printContainer(dll);
    
    //vector->get(0) = 300;
    
    //modifyContainer2(vector->get(0));
    
    //swap( vector->get(0), vector->get(1) );
    
    
//    printContainer(vector);
//    printContainer(dll);
    
    //testPushBack(stack);

    //IContainer container;
}


//
//  main.cpp
//  Lec_02_07_20
//
//  Created by Vidoje Mihajlovikj on 2/7/20.
//  Copyright © 2020 Vidoje Mihajlovikj. All rights reserved.
//

//#include <iostream>
//#include <stdio.h>
//
//class A
//{
//public:
//    A() {
//        std::cout << "A()" << std::endl;
//        init();
//    }
//
//    virtual void init() {
//        printf("A::virtual_function called\n");
//    }
//
//    virtual ~A() {
//    }
//};
//
//class B : public A
//{
//public:
//    B(){
//        std::cout << "B()" << std::endl;
//    }
//    // override virtual function in A
//    void init()
//    {
//        printf("B::virtual_function called\n");
//    }
//};
//
//class C : public A
//{
//public:
//    C(){
//        std::cout << "B()" << std::endl;
//    }
//    // override virtual function in A
//    void init()
//    {
//        printf("B::virtual_function called\n");
//    }
//};
//
//class D : public A
//{
//public:
//    D(){
//        std::cout << "B()" << std::endl;
//    }
//    // override virtual function in A
//    void init()
//    {
//        printf("B::virtual_function called\n");
//    }
//};
//
//int main(int argc, char **argv)
//{
//    // Call to virtual_function during construction doesn't
//    // behave like normal virtual function call.
//    // Print statement shows it invokes A::virtual_function,
//    // even though we are constructing an instance of B, not A.
//    B myObject;
//
//    // This call behaves like a normal virtual function call.
//    // Print statement shows it invokes B::virtual_function.
//    //myObject.virtual_function();
//
//    // insert code here...
//    std::cout << "Hello, World!\n";
//    return 0;
//}
