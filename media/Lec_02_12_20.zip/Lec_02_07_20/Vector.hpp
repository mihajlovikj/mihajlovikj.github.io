//
//  Vector.hpp
//  Lec_02_07_20
//
//  Created by Vidoje Mihajlovikj on 2/7/20.
//  Copyright © 2020 Vidoje Mihajlovikj. All rights reserved.
//

#ifndef Vector_h
#define Vector_h

#include "IContainer.hpp"
#include "IAccessor.hpp"
#include <iostream>

class Vector : public IContainer{
private:
    int * data;
    int capacity;
    int m_size;
    void resize(int newCapacity);
public:
    Vector(int capacity);
    void push_back(const int & element);
    void pop_back();
    //int get(int pos) const;
    int & get(int pos);
    int & operator[](int index);
    int size() const;
    ~Vector();
};

#endif /* Vector_h */
