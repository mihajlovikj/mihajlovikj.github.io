//
//  Vector.cpp
//  Lec_02_07_20
//
//  Created by Vidoje Mihajlovikj on 2/7/20.
//  Copyright © 2020 Vidoje Mihajlovikj. All rights reserved.
//

#include <stdio.h>
#include <iostream>
#include "Vector.hpp"

Vector::Vector(int initialCapacity) {
    if (initialCapacity <= 0) {
        throw std::invalid_argument("Empty vector.");
    }
    
    this->capacity = initialCapacity;
    this->m_size = 0;
    this->data = new int[this->capacity];
}

/**
 * Destructor
 */
Vector::~Vector() {
    delete[] this->data;
}

/**
 * Resizes the vector.
 *
 * @param newCapacity the new capacity of this vector
 */
void Vector::resize(int newCapacity) {
    this->capacity = newCapacity;
    int *temp = new int[this->capacity];
    
    for (int i = 0; i < this->m_size; i++) {
        temp[i] = this->data[i];
    }
    
    delete[] this->data;
    this->data = temp;
}

/**
 * Adds element to the end of the vector.
 *
 * @param element element the element to be pushed
 */
void Vector::push_back(const int &element) {
    if (this->m_size >= this->capacity) {
        this->resize(2 * this->capacity);
    }
    
    this->data[this->m_size] = element;
    this->m_size++;
}

/**
 * Removes the last element, throws std::std::out_of_range on error.
 */
void Vector::pop_back() {
    if (this->m_size == 0) {
        throw std::out_of_range("Empty vector.");
    }
    
    this->m_size--;
}

/**
 * Gets the data at the given position in the vector.
 *
 * @param pos the position that the target data locates
 * @return the data
 */
//int Vector::get(int pos) const {
//    if ((pos < 0) || (pos >= this->m_size)) {
//        throw std::out_of_range("Invalid pos or empty vector.");
//    }
//
//    return this->data[pos];
//}

int & Vector::operator[](int index){
    return this->get(index);
}
int & Vector::get(int pos) {
    if ((pos < 0) || (pos >= this->m_size)) {
        throw std::out_of_range("Invalid pos or empty vector.");
    }
    
    return this->data[pos];
}
//
int Vector::size() const{
    return this->m_size;
}

//void Vector::print(std::ostream out) const{
//    for (int i = 0; i < this->m_size; i++) {
//        out << get(i) << ", ";
//    }
//
//}

