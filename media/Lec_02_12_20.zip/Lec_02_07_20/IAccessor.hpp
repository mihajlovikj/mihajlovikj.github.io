//
//  IAccessor.hpp
//  Lec_02_07_20
//
//  Created by Vidoje Mihajlovikj on 2/11/20.
//  Copyright © 2020 Vidoje Mihajlovikj. All rights reserved.
//

#ifndef IAccessor_h
#define IAccessor_h

class IAccessor{
public:
    virtual int & get(int pos) = 0;
};

#endif /* IAccessor_h */
