//
//  IContainer.hpp
//  Lec_02_07_20
//
//  Created by Vidoje Mihajlovikj on 2/7/20.
//  Copyright © 2020 Vidoje Mihajlovikj. All rights reserved.
//

#ifndef IContainer_h
#define IContainer_h
#include <iostream>
#include "IAccessor.hpp"

class IContainer : public IAccessor{
public:
    virtual void push_back(const int & element) = 0;
    virtual void pop_back() = 0;
  
    virtual int & get(int pos) = 0;
    virtual int size() const = 0;
    virtual int & operator[](int index) = 0;
      //virtual int get(int pos) const = 0;
    //virtual void print(std::ostream out) const = 0;
    
    //virtual void push_front(const int & element) = 0;
//    virtual void pop_back() = 0;
//    virtual void pop_front() = 0;
//    virtual int front() const = 0;
//    virtual int back() const = 0;
//    virtual void insert(int pos, int elem) = 0;
//    virtual void erase(int pos) = 0;
//    virtual int size() const = 0;
//    virtual int get(int pos) const = 0;
    virtual ~IContainer() {}
    
};
#endif /* IContainer_h */
