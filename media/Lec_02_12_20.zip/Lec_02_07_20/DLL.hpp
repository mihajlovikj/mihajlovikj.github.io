//
//  Stack.hpp
//  Lec_02_07_20
//
//  Created by Vidoje Mihajlovikj on 2/7/20.
//  Copyright © 2020 Vidoje Mihajlovikj. All rights reserved.
//

#ifndef Stack_h
#define Stack_h
#include "IContainer.hpp"
#include "IAccessor.hpp"

class Node {
private:
    int data;
    Node *previous;
    Node *next;
    
public:
    Node(int data);
    
    void set_next(Node *next);
    
    void set_previous(Node *previous);
    
    Node *get_next() const;
    
    Node *get_previous() const;
    
    int get_data() const;
    
    int & get_data();
};


class DLL : public IContainer{
private:
    int count;        // count keeps track of how many items are in the DLL.
    Node *head;        // head points to the first node in our DLL.
    Node *tail;          //tail points to the last node in our DLL.
    void insert(int pos, int item);
    void push_front(int item);
public:
    typedef Node * itr;
    DLL();
    void push_back(const int & element);
    void pop_back();
    //int get(int pos) const;
    int & get(int pos);
    int & operator[](int index);
    int size() const;
    ~DLL();
};

#endif /* Stack_h */
