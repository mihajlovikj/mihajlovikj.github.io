//
//  main.cpp
//  Lec5_InClass
//
//  Created by Vidoje Mihajlovikj on 1/21/20.
//  Copyright © 2020 Vidoje Mihajlovikj. All rights reserved.
//

#include <iostream>

class Rectangle{
    
private:
    int m_width;
    int m_height;
    int * age;
public:
    Rectangle() : Rectangle(0,0) {
        std::cout << "Constructor: Rectangle()"<<std::endl;
        
    }
    
    Rectangle(int width, int height) : m_width(width), m_height(height){
        std::cout << "Cunstructor: Rectangle (" << width << "," << height << ")" << std::endl;
        this->age = new int(5);
        
    }
    
    
    //Copy constructor
    Rectangle( const Rectangle & other){
        std::cout << "Copy Constructor: Rectangle(const Rectangle & other) "<<std::endl;
        this->m_height = other.m_height;
        this->m_width = other.m_width;
        this->age = other.age;
        
    }
    //Equals operator
    Rectangle & operator=(const Rectangle & other){
        std::cout << "operator=(const Rectangle & other)" << std::endl;
        this->m_height = other.m_height;
        this->m_width = other.m_width;
        this->age = other.age;
        return *this;
    }
    
    bool operator==(const Rectangle & other){
        return this->m_height == other.getHeight() && this->m_width == other.getWidth();
    }
    

    

    int getWidth() const { return this->m_width;}
    int getHeight() const { return this->m_height; }
    void setHeight(int height){
        this->m_height = height;
    }
    
    void setWidth(int width){
        this->m_width = width;
    }
    
    ~Rectangle(){
        std::cout << "Goodbye" << std::endl;
        delete this->age;
    }
};

bool operator<(const Rectangle & other, const Rectangle another ){
    return other.getHeight() < another.getHeight() && other.getWidth() < another.getWidth();
}


bool operator<(const Rectangle & other, const int & another ){
    return other.getHeight() < another;
}
std::ostream & operator<<(std::ostream & out, const Rectangle & other){
    out << other.getWidth() << ", " << other.getHeight() << std::endl;
    return out;
}

std::istream & operator>>(std::istream & in,Rectangle & other){
    int w,h;
    in >> w >> h;
    other.setWidth(w);
    other.setHeight(h);
    return in;
}

int main(int argc, const char * argv[]) {
    Rectangle rC(2,3);
    return 0;
}
