//
//  main.cpp
//  Lec9_InClass
//
//  Created by Vidoje Mihajlovikj on 2/4/20.
//  Copyright © 2020 Vidoje Mihajlovikj. All rights reserved.
//

#include <iostream>
#include <memory>
class Print{
public:
    virtual void printMe() = 0;
};

class Shape{
protected:
    int x;
    int y;
    std::string color;
    int * someData;
public:
    Shape(int x, int y, std::string  color) : x(x), y(y), color(color){
        std::cout << "Shape(x,y,color) " << std::endl;
        someData = new int(100);
    }
    
    virtual void print(){
        std::cout << this->x << " " << this->y  << " " << this->area() << std::endl;
    }
    
    virtual double area2(){ return 5; }
    virtual double area() { return 0;};
    
    ~Shape(){
        if ( this->someData != NULL ){
            std::cout << "~Shape() " << std::endl;
            delete this->someData;
        }
    }
};

class Rectangle : public Shape, public Print{
private:
    int w;
    int h;
public:
    Rectangle() : Rectangle(0,0,0,0,"black"){
        std::cout << "Rectangle()" << std::endl;
    }
    
    Rectangle(int x, int y, int w, int h, std::string color) : Shape(x,y, color){
        this->w = w;
        this->h = h;
        std::cout << "Rectangle(x,y,w,h,color) " << std::endl;
    }
    
//    void print(){
//        std::cout << "Surpirse surprise! Rectangle. " << std::endl;
//    }
    double area2(){ return 50; }
    
    double area(){
        return this->w * this->h;
    }
    
    void printMe(){
        std::cout << "Fancy print! " << std::endl;
    }
   
    
    ~Rectangle(){
        
        std::cout << "~Rectangle() " << std::endl;
    }
};


void foo(Print & shape){
    shape.printMe();
}

int main(int argc, const char * argv[]) {

    Shape * r1 = new Shape(0,0,"black");
    delete r1;
//    std::cout << r1->area2() << std::endl;
//    delete r1;
    //delete r1;
//    Rectangle r1(5,5,10,10, "red");
//    r1.printMe();
//    Circle c1(15,15, 20, "green");
//    std::cout << "-------" << std::endl;
//    foo(r1);
//    std::cout << "-------" << std::endl;
//    //c1.print();
    
    std::cout << "Hello, World!\n";
    return 0;
}





